ReadMe File

Name : Vishal Venkat Raman
Net ID : vxv140330

Files List : 
ComputeInformationGain.java
DecisionTreeML.java
TreeNode.java

Compilation Instructions 
(Example to print the decision tree):
DecisionTreeML.java 10 C:/Users/Vishal/Desktop/ML/data_sets1/training_set.csv C:/Users/Vishal/Desktop/ML/data_sets1/validation_set.csv C:/Users/Vishal/Desktop/ML/data_sets1/test_set.csv 1

(Example to not print the decision tree):
DecisionTreeML.java 10 C:/Users/Vishal/Desktop/ML/data_sets1/training_set.csv C:/Users/Vishal/Desktop/ML/data_sets1/validation_set.csv C:/Users/Vishal/Desktop/ML/data_sets1/test_set.csv 0